Unfortunately I wasn't able to find a way to package the python into an application

So here are some steps to install "Wine" (An application that allows MacOS users to use Windows .exe files):
1. Open the terminal by clicking F4 and writing "terminal"
2. Paste in this command: /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
3. Paste in this command: brew install --cask --no-quarantine wine-stable
4. Close the terminal
5. Open the .ZIP file
6. Run the app named "Whale Vs Plastic.exe"