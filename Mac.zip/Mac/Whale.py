# For version 2.0
    # Add more sound effects
    # Make existing sound effects better
    # Add upgrades
    # Add animations to characters
    # Add upgrades to characters
    # Add different skins
    # Make better icon for game
    # Add a fish net that gives various fishes for fish ammo
    # Add settings button
    # Try to make the reset function look smoother
    # Make ammo counter look better
    # Make tutorial better
    # Solve the time.sleep error
    # Solve whale health problem (when whale dies whale_health is sometimes 1, 0 or -1)
    # Solve the game_over part of the spawn rate
    # Make it work with multiple languages (change the language)

import pygame
import math
import random
import time

pygame.init()

WIDTH, HEIGHT = 1000, 500
FPS = 60

RED = (255, 0, 0)
YELLOW = (255, 255, 0)
ORANGE = (255, 165, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

angle = random.randint(0, 360)
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Whale VS Plastic")

whale_img = pygame.transform.scale(pygame.image.load("assets/whale.png").convert_alpha(), (300, 125))
bullet_img = pygame.image.load("assets/fish_bullet.png").convert_alpha()
BG = pygame.transform.scale(pygame.image.load("assets/background_img.png").convert(), (2000, HEIGHT))
start = pygame.transform.scale(pygame.image.load("assets/Buttons/start.png").convert_alpha(), (228, 112))
exit = pygame.transform.scale(pygame.image.load("assets/Buttons/exit.png").convert_alpha(), (223, 112))
settings = pygame.transform.scale(pygame.image.load("assets/Buttons/settings.png").convert_alpha(), (340, 112))
continues = pygame.transform.scale(pygame.image.load("assets/Buttons/continue.png").convert_alpha(), (350, 112))
restart = pygame.transform.scale(pygame.image.load("assets/Buttons/restart.png").convert_alpha(), (350, 112))
icon_img = pygame.image.load("assets/Icon/icon.ico").convert_alpha()

hurt_sound = pygame.mixer.Sound("assets/Sounds/hurt.wav")
hurt_sound.set_volume(0.05)

health_sound = pygame.mixer.Sound("assets/Sounds/health.wav")
health_sound.set_volume(0.05)

ammo_sound = pygame.mixer.Sound("assets/Sounds/ammo.wav")
ammo_sound.set_volume(0.03)

bg_music_sound = pygame.mixer.Sound("assets/Sounds/bg_music.wav")
bg_music_sound.set_volume(0.05)

shooting_sound = pygame.mixer.Sound("assets/Sounds/shooting.wav")
shooting_sound.set_volume(0.05)

btn_click_sound = pygame.mixer.Sound("assets/Sounds/button_click.wav")
btn_click_sound.set_volume(0.1)

hit_sound = pygame.mixer.Sound("assets/Sounds/hit.wav")
hit_sound.set_volume(0.2)

game_over_sound = pygame.mixer.Sound("assets/Sounds/game_over.wav")
game_over_sound.set_volume(0.1)

pygame.display.set_icon(icon_img)

moving_left = False
moving_right = False
moving_up = False
moving_down = False

clock = pygame.time.Clock()
run = True
started = True
tutorial = True
game_over_screen = True
paused = True

pb_speed = 2
sc_speed = 2
anchor_speed = 2
fish_speed = 8
fish2_speed = 5
ammo_speed = 10

game_active = True

bg_width = BG.get_width()

scroll = 0
scroll_number = 3
tiles = math.ceil(WIDTH / bg_width) + 1

ammo_sr = 30000
ammo_st = pygame.time.get_ticks()

anchor_sr = 10000
anchor_t = pygame.time.get_ticks()

pb_sr = 3000
pbt = pygame.time.get_ticks()

sc_sr = 2000
sct = pygame.time.get_ticks()

fish_sr = 20000
fst = pygame.time.get_ticks()

fish2_sr = 10000
f2st = pygame.time.get_ticks()

score_width = 0
high_score_width = 0

def load_high_score():
    try:
        with open("assets/Highscore/highscore.txt", "r") as file:
            return int(file.read())
    
    except FileNotFoundError:
        print("File not found!")
        return 0

def save_high_score(high_score):
    with open("assets/Highscore/highscore.txt", "w") as file:
        file.write(str(high_score))

def display_score(score, screen, x, y, text_size, color):
    global score_width

    score_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", text_size)

    score_text = score_font.render(f"Score: {score}", True, color)

    score_rect = score_text.get_rect()
    
    score_width = score_rect.width

    screen.blit(score_text, (x, y))

def display_high_score(high_score, screen, x, y, text_size, color):
    global high_score_width

    high_score_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", text_size)

    high_score_text = high_score_font.render(f"High score: {high_score}", True, color)

    high_score_rect = high_score_text.get_rect()
    
    high_score_width = high_score_rect.width

    screen.blit(high_score_text, (x, y))

score = 0
high_score = load_high_score()
last_score = 0

pause_time = 0
total_pause_time = 0

class Whale(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()
        self.x = x
        self.y = y
        self.orig_x = self.x
        self.orig_y = self.y
        self.direction = 1
        self.image_width = image.get_width()
        self.image_height = image.get_height()
        self.image = image
        self.original_image = image
        self.current_health = 200
        self.max_health = 200
        self.target_health = 200
        self.vel = 5
        self.whale_mask = pygame.mask.from_surface(image)
        self.rect = self.image.get_rect()
        self.delay = 200
        self.last_shot = pygame.time.get_ticks()
        self.fish_ammo = 5
        self.orig_fish_ammo = self.fish_ammo
        self.max_fish_ammo = 30

    def update(self):
        if moving_left and not moving_right and self.x > 0:
            self.x -= self.vel
            self.image = pygame.transform.flip(whale_img, True, False)
            self.direction = -1
        if moving_right and not moving_left and (self.x + self.image_width) < WIDTH:
            self.x += self.vel
            self.image = self.original_image
            self.direction = 1
        if moving_up and not moving_down and self.y > 0:
            self.y -= self.vel
        if moving_down and not moving_up and (self.y + self.image_height) < HEIGHT:
            self.y += self.vel
        if moving_up and moving_left and not moving_right:
            self.image = pygame.transform.flip(whale_img, True, False)
            self.direction = -1
        if moving_down and moving_right and not moving_left:
            self.image = self.original_image
            self.direction = 1

        self.rect.topleft = (self.x, self.y)

    def shoot(self):
        time = pygame.time.get_ticks()

        if time - self.last_shot >= self.delay and self.fish_ammo > 0:
            self.last_shot = time
            bullet = Bullet(whale.rect.centerx + ((whale.image_width/2 + 10) * whale.direction), whale.rect.centery, whale.direction, bullet_img)
            bullet_group.add(bullet)
            shooting_sound.play()
            self.fish_ammo -= 1

    def draw_ammo(self, window):
        ammo_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", 18)

        ammo_image = pygame.transform.rotate(pygame.transform.scale(pygame.image.load("assets/fish_bullet.png").convert_alpha(), (35, 7)), 45)

        text = ammo_font.render(f"X {self.fish_ammo}", True, BLACK)
        text_rect = text.get_rect()
        text_rect.x = 58
        text_rect.y = 80

        window.blit(ammo_image, (28, 75))
        window.blit(text, text_rect)

    def draw_health_bar(self, window):
        transition_speed = 3
        health_ratio = self.current_health / self.max_health
        health_bar_width = 200 * health_ratio

        heart = pygame.transform.scale(pygame.image.load("assets/heart.png"), (68, 61))

        color = GREEN

        pixel_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", 14)

        if whale.current_health <= 100:
            color = YELLOW
        if whale.current_health <= 50:
            color = ORANGE
        if whale.current_health <= 10:
            color = RED

        if self.current_health < self.target_health:
            self.current_health += transition_speed
            if self.current_health > self.target_health:
                self.current_health = self.target_health
        if self.current_health > self.target_health:
            self.current_health -= transition_speed
            if self.current_health < self.target_health:
                self.current_health = self.target_health

        text_percentage = pixel_font.render((str(int(health_ratio * 100)) + "%"), True, BLACK)

        heart_rect = heart.get_rect(topleft=(6, 1))

        text_rect = text_percentage.get_rect(center=heart_rect.center)

        pygame.draw.rect(window, BLACK, (55, 15, 208, 37), 0, 9, 0, 9, 0)

        pygame.draw.rect(window, color, (59, 19.5, health_bar_width, 29),
                         0, 5, 0, 5, 0, 5)

        pygame.draw.rect(window, BLACK, (55, 15, 208, 37),
                         5, 9, 0, 9, 0, 9)

        window.blit(heart, (5, 5))
        window.blit(text_percentage, text_rect)

    def increase_health(self, amount):
        self.target_health = min(self.max_health, self.target_health + amount)

    def reduce_health(self, amount):
        self.target_health = max(0, self.target_health + amount)

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))
        self.draw_health_bar(window)
        self.draw_ammo(window)

class Button:
    def __init__(self, x, y, img):
        self.width = img.get_width()
        self.height = img.get_height()
        self.img = img
        self.rect = self.img.get_rect()   
        self.rect.topleft = (x, y)
        self.clicked = False

    def draw(self):
        button_action = False

        pos = pygame.mouse.get_pos()
        
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                button_action = True
                btn_click_sound.play()
                

        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False

        screen.blit(self.img, (self.rect.x, self.rect.y))

        return button_action


class HorizontalEnemies(pygame.sprite.Sprite):
    def __init__(self, img, x, y, speed, max_health):
        super().__init__()
        self.image = img
        self.x = x
        self.y = y
        self.current_health = max_health
        self.max_health = max_health
        self.speed = speed
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.mask = pygame.mask.from_surface(self.image)

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

    def update(self):
        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()


class VerticalEnemies(pygame.sprite.Sprite):
    def __init__(self, img, x, y, speed, max_health):
        super().__init__()
        self.image = img
        self.x = x
        self.y = y
        self.speed = speed
        self.current_health = max_health
        self.max_health = max_health
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.mask = pygame.mask.from_surface(self.image)
        self.width = self.image.get_width()
        self.height = self.image.get_height()

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

    def update(self):

        self.rect.y += self.speed
        if self.rect.bottom > HEIGHT:
            self.kill()


class HealthGivers(pygame.sprite.Sprite):
    def __init__(self, img, x, y, speed):
        super().__init__()
        self.image = img
        self.x = x
        self.y = y
        self.speed = speed
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.mask = pygame.mask.from_surface(self.image)

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

    def update(self):

        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()


class AmmoGivers(pygame.sprite.Sprite):
    def __init__(self, img, x, y, speed):
        super().__init__()
        self.image = img
        self.x = x
        self.y = y
        self.speed = speed
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.mask = pygame.mask.from_surface(self.image)
        self.image = pygame.transform.flip(self.image, True, False)

    def draw(self, window):
        window.blit(self.image, (self.x, self.y))

    def update(self):

        self.rect.x -= self.speed
        if self.rect.right < 0:
            self.kill()

def start_screen():
    global run
    global started
    global tutorial

    start_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", 50)

    text = start_font.render("MAIN MENU", True, WHITE)
    text_rect = text.get_rect(centerx=WIDTH/2)
    text_rect.y = 20

    start_button = Button((WIDTH/2)-(start.get_width()/2), 220, start)
    exit_button = Button((WIDTH/2)-(exit.get_width()/2), 350, exit)

    while started:
        screen.fill((56, 205, 242))

        screen.blit(text, text_rect)

        if start_button.draw():
            started = False
        if exit_button.draw():
            started = False
            tutorial = False
            run = False

        display_high_score(high_score, screen, (WIDTH / 2) - (high_score_width/ 2), 130, 30, WHITE)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                started = False
                tutorial = False
                run = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    started = False
                    tutorial = False
                    run = False

        pygame.display.update()
        clock.tick(FPS)

    save_high_score(high_score)

def reset():
    global moving_right, moving_down, moving_left, moving_up, ammo_st, anchor_t, pbt, sct, fst, f2st, score, last_score, pb_speed, sc_speed, anchor_speed, ammo_speed, fish_speed, fish2_speed, scroll_number, start_time, game_active, total_pause_time

    whale.x = whale.orig_x
    whale.y = whale.orig_y
    whale.direction = 1
    whale.image = whale.original_image
    whale.fish_ammo = whale.orig_fish_ammo
    whale.current_health = whale.max_health
    whale.target_health = whale.max_health

    moving_up = False
    moving_down = False
    moving_left = False
    moving_right = False

    bg_music_sound.stop()
    bg_music_sound.play(loops=-1)

    ammo_st = current_time
    anchor_t = current_time
    pbt = current_time
    sct = current_time
    fst = current_time
    f2st = current_time

    pb_speed = 2
    sc_speed = 2
    anchor_speed = 2
    ammo_speed = 10
    fish_speed = 8
    fish2_speed = 5

    scroll_number = 3

    score = 0
    last_score = 0

    start_time = time.time()
    total_pause_time = 0

    game_active = True

    for vert_enemy in anchor_group:
        vert_enemy.kill()

    for bullet in bullet_group:
        bullet.kill()

    for pb in pb_group:
        pb.kill()

    for sc in sc_group:
        sc.kill()

    for fish in fish_group:
        fish.kill()

    for fish2 in fish2_group:
        fish2.kill()

    for ammo in ammo_group:
        ammo.kill()

def tutorial_screen():
    global run
    global tutorial

    continues = pygame.transform.scale(pygame.image.load("assets/Buttons/continue.png").convert_alpha(), (300, 82))

    continue_button = Button((WIDTH/2)-(continues.get_width()/2), 410, continues)

    start_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", 50)
    start_font2 = pygame.font.Font("assets/Fonts/pixel_font.ttf", 30)

    text = start_font.render("TUTORIAL", True, WHITE)
    text_rect = text.get_rect(centerx = WIDTH/2)
    text_rect.y = 10

    text2 = start_font2.render("1. Use the arrow keys on your keyboard to move", True, WHITE)
    text2_rect = text.get_rect(x = 10)
    text2_rect.y = 95

    text3 = start_font2.render("2. Press left SHIFT to shoot", True, WHITE)
    text3_rect = text.get_rect(x = 10)
    text3_rect.y = 145

    text4 = start_font2.render("3. Press TAB to pause the game", True, WHITE)
    text4_rect = text.get_rect(x = 10)
    text4_rect.y = 195

    text5 = start_font2.render("4. Water bottles, soda cans and anchors hurt you, shoot them", True, WHITE)
    text5_rect = text.get_rect(x = 10)
    text5_rect.y = 245

    text6 = start_font2.render("5. The blue and gold fish give you health", True, WHITE)
    text6_rect = text.get_rect(x = 10)
    text6_rect.y = 295

    text7 = start_font2.render("6. The long fish give you ammo", True, WHITE)
    text7_rect = text.get_rect(x = 10)
    text7_rect.y = 345

    while tutorial:

        screen.fill((56, 205, 242))

        screen.blit(text, text_rect)
        screen.blit(text2, text2_rect)
        screen.blit(text3, text3_rect)
        screen.blit(text4, text4_rect)
        screen.blit(text5, text5_rect)
        screen.blit(text6, text6_rect)
        screen.blit(text7, text7_rect)

        if continue_button.draw():
            tutorial = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                tutorial = False
                run = False
            
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    tutorial = False
                    run = False
        
        pygame.display.update()
        clock.tick(FPS)

def game_over():
    global run
    global game_over_screen

    bg_music_sound.stop()

    restart_button = Button((WIDTH/2)-(continues.get_width()/2), 240, restart)
    exit_button = Button((WIDTH/2)-(exit.get_width()/2), 370, exit)

    start_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", 50)

    text = start_font.render("GAME OVER", True, WHITE)
    text_rect = text.get_rect(centerx=WIDTH/2)
    text_rect.y = 20

    while game_over_screen:

        screen.fill((56, 205, 242))

        screen.blit(text, text_rect)

        if restart_button.draw():
            reset()
            game_over_screen = False
        if exit_button.draw():
            game_over_screen = False
            run = False

        display_score(score, screen, (WIDTH/2) - (score_width/2), 120, 30, WHITE)
        display_high_score(high_score, screen, (WIDTH/2) - (high_score_width/2), 160, 30, WHITE)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over_screen = False
                run = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    game_over_screen = False
                    run = False
        
        pygame.display.update()
        clock.tick(FPS)

    save_high_score(high_score)

def paused_game():
    global run
    global paused
    global pause_time
    global total_pause_time

    bg_music_sound.stop()

    paused = True
    pause_time = time.time()

    start_font = pygame.font.Font("assets/Fonts/pixel_font.ttf", 50)

    text = start_font.render("PAUSED", True, WHITE)
    text_rect = text.get_rect(centerx=WIDTH/2)
    text_rect.y = 20

    continue_button = Button((WIDTH/2)-(continues.get_width()/2), 125, continues)
    restart_button = Button((WIDTH/2)-(continues.get_width()/2), 250, restart)
    exit_button = Button((WIDTH/2)-(exit.get_width()/2), 375, exit)

    while paused:
        
        screen.fill((56, 205, 242))
        
        screen.blit(text, text_rect)

        if continue_button.draw():
            paused = False
            total_pause_time += time.time() - pause_time
        if restart_button.draw():
            reset()
            paused = False
        if exit_button.draw():
            paused = False
            run = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                paused = False
                run = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    paused = False
                    run = False

        pygame.display.update()
        clock.tick(FPS)

class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, direction, img):
        super().__init__()
        self.x = x
        self.y = y
        self.direction = direction
        self.image = img
        self.orig_img = img
        self.vel = 10
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.bullet_mask = pygame.mask.from_surface(self.image)

        if self.direction == -1:
            self.image = pygame.transform.flip(self.image, True, False)
        if self.direction == 1:
            self.image = self.orig_img
    
    def update(self):

        self.rect.x += (self.direction * self.vel)

        if self.rect.right < 0 or self.rect.left > WIDTH:
            self.kill()

whale = Whale(100, 200, whale_img)

bullet_group = pygame.sprite.Group()
ammo_group = pygame.sprite.Group()
anchor_group = pygame.sprite.Group()
pb_group = pygame.sprite.Group()
sc_group = pygame.sprite.Group()
fish_group = pygame.sprite.Group()
fish2_group = pygame.sprite.Group()

start_screen()
tutorial_screen()

bg_music_sound.play(loops=-1)

start_time = time.time()

while run:

    current_time = pygame.time.get_ticks()

    for i in range(0, tiles):
        screen.blit(BG, (i * bg_width + scroll, 0))

    scroll -= scroll_number

    if abs(scroll) > bg_width:
        scroll = 0

    current_time = pygame.time.get_ticks()

    if current_time - anchor_t > anchor_sr:
        anchor_x = random.randrange(WIDTH)
        anchor_img = pygame.transform.scale(pygame.image.load("assets/anchor.png").convert_alpha(), (130, 500))
        anchor_height = anchor_img.get_height()
        anchor_y = 0 - anchor_height
        anchor_group.add(VerticalEnemies(anchor_img, anchor_x, anchor_y, anchor_speed, 100))
        anchor_t = current_time

    if current_time - pbt > pb_sr:
        pb_x = WIDTH
        pb_y = random.randrange(HEIGHT)
        angle = random.randint(0, 360)
        pb_img = pygame.transform.rotate(
            pygame.transform.scale(pygame.image.load("assets/plastic_bottle.png").convert_alpha(), (24, 72)), angle)
        pb_group.add(HorizontalEnemies(pb_img, pb_x, pb_y, pb_speed, 50))
        pbt = current_time

    if current_time - fst > fish_sr:
        fish_x = WIDTH
        fish_y = random.randrange(HEIGHT)
        fish_img = pygame.transform.flip(pygame.transform.scale(pygame.image.load("assets/fish.png").convert_alpha(), (60, 35)), True, False)
        fish_group.add(HealthGivers(fish_img, fish_x, fish_y, fish_speed))
        fst = current_time

    if current_time - f2st > fish2_sr:
        fish2_x = WIDTH
        fish2_y = random.randrange(HEIGHT)
        fish2_img = pygame.transform.flip(pygame.transform.scale(pygame.image.load("assets/fish2.png").convert_alpha(), (97, 37)), True, False)
        fish2_group.add(HealthGivers(fish2_img, fish2_x, fish2_y, fish2_speed))
        f2st = current_time

    if current_time - sct > sc_sr:
        sc_x = WIDTH
        sc_y = random.randrange(HEIGHT)
        angle = random.randint(0, 360)
        sc_img = pygame.transform.rotate(pygame.transform.scale(pygame.image.load("assets/soda_can.png").convert_alpha(), (28, 52)), angle)
        sc_group.add(HorizontalEnemies(sc_img, sc_x, sc_y, sc_speed, 50))
        sct = current_time

    if current_time - ammo_st > ammo_sr:
        ammo_x = WIDTH
        ammo_y = random.randrange(HEIGHT)
        angle = random.randint(0, 360)
        ammo_img = pygame.transform.scale(pygame.image.load("assets/fish_bullet.png").convert_alpha(), (100, 17))
        ammo_group.add(AmmoGivers(ammo_img, ammo_x, ammo_y, ammo_speed))
        ammo_st = current_time

    for vert_enemy in anchor_group:
        if pygame.sprite.collide_mask(whale, vert_enemy):
            print("Collision with anchor!")
            vert_enemy.kill()
            whale.reduce_health(-40)
            hurt_sound.play()
        for bullet in bullet_group:
            if pygame.sprite.collide_mask(vert_enemy, bullet):
                vert_enemy.kill()
                bullet.kill()
                hit_sound.play()

    for pb in pb_group:
        if pygame.sprite.collide_mask(whale, pb):
            print("Collision with plastic bottle!")
            pb.kill()
            whale.reduce_health(-20)
            hurt_sound.play()
        for bullet in bullet_group:
            if pygame.sprite.collide_mask(pb, bullet):
                pb.kill()
                bullet.kill()
                hit_sound.play()

    for sc in sc_group:
        if pygame.sprite.collide_mask(whale, sc):
            print("Collision with soda can!")
            sc.kill()
            whale.reduce_health(-10)
            hurt_sound.play()
        for bullet in bullet_group:
            if pygame.sprite.collide_mask(sc, bullet):
                sc.kill()
                bullet.kill()
                hit_sound.play()

    for fish in fish_group:
        if pygame.sprite.collide_mask(whale, fish):
            print("Collision with Fish!")
            if whale.current_health < whale.max_health:
                whale.increase_health(40)
                health_sound.play()
            fish.kill()

    for fish2 in fish2_group:
        if pygame.sprite.collide_mask(whale, fish2):
            print("Collision with Fish!")
            if whale.current_health < whale.max_health:
                whale.increase_health(40)
                health_sound.play()
            fish2.kill()

    for ammo in ammo_group:
        if pygame.sprite.collide_mask(whale, ammo):
            print("Collision with Ammo!")
            if whale.fish_ammo < whale.max_fish_ammo:
                whale.fish_ammo += 3
                ammo_sound.play()
            ammo.kill()

    if whale.current_health <= 0:
        game_active = False
        whale.current_health = -1
        game_over_sound.play()
        time.sleep(1)
        game_over()

    pb_group.update()
    pb_group.draw(screen)

    sc_group.update()
    sc_group.draw(screen)

    fish_group.update()
    fish_group.draw(screen)

    fish2_group.update()
    fish2_group.draw(screen)

    anchor_group.update()
    anchor_group.draw(screen)
    
    bullet_group.update()
    bullet_group.draw(screen)

    ammo_group.update()
    ammo_group.draw(screen)

    whale.update()
    whale.draw(screen)

    display_score(score, screen, (WIDTH / 2) - (score_width / 2), 20, 18, BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                run = False
            if event.key == pygame.K_RIGHT:
                moving_right = True
            if event.key == pygame.K_LEFT:
                moving_left = True
            if event.key == pygame.K_UP:
                moving_up = True
            if event.key == pygame.K_DOWN:
                moving_down = True
            if event.key == pygame.K_TAB:
                print("paused")
                paused_game()
                bg_music_sound.stop()
                bg_music_sound.play(loops=-1)
            if event.key == pygame.K_LSHIFT:
                whale.shoot()

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_RIGHT:
                moving_right = False
            if event.key == pygame.K_LEFT:
                moving_left = False
            if event.key == pygame.K_UP:
                moving_up = False
            if event.key == pygame.K_DOWN:
                moving_down = False
    
    if game_active:
        score = int((time.time() - start_time - total_pause_time) / 3)

    if score > last_score + 10:
        pb_speed += 1
        sc_speed += 1
        anchor_speed += 1
        fish_speed += 1
        fish2_speed += 1
        ammo_speed += 1

        for pb in pb_group:
            pb.speed += 1
        for sc in sc_group:
            sc.speed += 1
        for anchor in anchor_group:
            anchor.speed += 1
        for fish in fish_group:
            fish.speed += 1
        for fish2 in fish2_group:
            fish2.speed += 1
        for ammo in ammo_group:
            ammo.speed += 1

        scroll_number += 1
        
        last_score = score

    if score > high_score:
        high_score = score

    pygame.display.update()
    clock.tick(FPS)

save_high_score(high_score)

pygame.quit()